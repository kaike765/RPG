# Aetheria — personagem preparado, versão experimental

## Correção importante
A inspeção visual da geometria confirmou que Personagem.glb contém um humano. A identificação anterior como cidade estava errada. O fato de arquivos terem o mesmo hash só demonstra igualdade de conteúdo, não o tipo de objeto.

## O que foi efetivamente produzido
- Malha original preservada, com UV e textura de cor.
- Esqueleto automático de 22 ossos.
- Até quatro influências por vértice, com pesos normalizados.
- GLB com skin, matrizes de bind e seis animações procedurais: Idle, Walk, Run, Sprint, Jump e Attack.
- Projeto Unity com importação própria dos dados da malha e rig. Não exige importador GLB para testar o personagem.
- Gerador de SkinnedMeshRenderer, Animator Controller Generic, Blend Tree 1D e cena de testes.
- Movimento em terceira pessoa, câmera, pulo e animação de ataque.

## O que NÃO é
Não é o RPG completo solicitado. É uma entrega real de preparação do personagem que faltava, sem afirmar que o restante do jogo foi concluído.
Não foi executado na Unity, Blender ou num validador oficial de glTF. As verificações feitas são estruturais e matemáticas, não aprovação visual das deformações.
O rig foi estimado por posições geométricas; não é um rig de produção revisado manualmente. Não há dedos, face, ossos de cabelo, ossos de roupa, IK ou física secundária. Pesos de roupas longas e ombros devem ser corrigidos manualmente. Os clips são movimentos procedurais simples; não são motion capture nem animações artísticas finais. Velocidades de animação e de deslocamento precisam de ajuste para reduzir foot sliding.

## Como abrir
1. Extraia a pasta AetheriaPersonagem.
2. Unity Hub > Add project from disk > selecione a pasta com Assets, Packages e ProjectSettings.
3. Use Unity 6000.0.23f1 ou um patch compatível da linha 6000.0.
4. Aguarde URP 17.0.3 e Input System 1.11.2 serem instalados.
5. Aceite reiniciar o Editor se o Input System pedir. Active Input Handling = Input System Package (New) ou Both.
6. Confira erros de compilação no Console.
7. Menu Aetheria > Preparar personagem e gerar cena de teste.
8. Pressione Play na Game View.

O gerador cria a cena em Assets/AetheriaCharacter/Generated/CharacterTest.unity e um prefab Player. Não sobrescreve o projeto anterior: este é um projeto independente. Se copiar Assets/AetheriaCharacter para outro projeto, faça backup; o gerador altera o URP ativo e usa uma nova cena. Reconstruir apaga a pasta Generated.
O prefab exige referência externa de câmera ao ser reutilizado em outra cena.

## Controles
WASD: mover; Shift: sprint; Ctrl: caminhar; Espaço: pular.
Mouse: câmera; clique esquerdo: tocar animação de ataque; Esc: alternar cursor.
O ataque desta cena apenas testa animação: não há dano, inimigos ou campanha neste pacote.

## GLB exportado
RigExport/Personagem_AutoRig_Experimental.glb é a versão skinned para inspeção em ferramentas 3D. A Unity não precisa importar esse GLB para executar a cena: o builder usa os dados binários e JSON fornecidos.
O Animator desta entrega é Generic. Não existe um Avatar Humanoid validado; configurar Humanoid exige mapear e revisar ossos e pose de referência no Editor.

## Verificações obrigatórias
- Abrir, compilar e gerar cena sem erros.
- Reabrir a cena e confirmar ausência de Missing Script.
- Inspecionar ombros, cotovelos, joelhos, roupa, cabelo e mãos em cada clip.
- Verificar orientação frontal da textura e do personagem. O eixo Z foi espelhado para a Unity.
- Checar face/cabelo: double-sided foi usado para acomodar superfícies finas.
- Confirmar pulo, aterrissagem, câmera e colisão com obstáculos.
- Gerar Development Build antes de distribuir.
- Fazer profiling; HUD OnGUI aloca strings e não é UI final.

## Materiais e limitações de renderização
Shader toon simples com textura, luz direcional, sombra e preenchimento SH. Sem luzes adicionais, outline, specular, rim, alpha clipping, DepthNormals, lightmaps ou pós-processamento nesta entrega específica. O pacote anterior contém outros recursos, mas não foi mesclado automaticamente.
O arquivo mapa-sem-textura.glb não foi incorporado como cenário: precisa de inspeção independente antes de ser tratado como mapa navegável. Não vou fabricar uma integração que não foi realizada.

## Direitos
Código gerado pode ser adaptado ao seu projeto. Os direitos do modelo e das texturas enviados pelo usuário não foram verificados; não se presume licença para redistribuição comercial. Unity e pacotes seguem seus próprios termos.
