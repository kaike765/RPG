using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.IO;
namespace AetheriaCharacter.Editor
{
 public static class CharacterBuilder
 {
  const string Data="Assets/AetheriaCharacter/Data/";
  const string Output="Assets/AetheriaCharacter/Generated";
  [MenuItem("Aetheria/Preparar personagem e gerar cena de teste")]
  public static void Generate()
  {
   if(!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())return;
   if(AssetDatabase.IsValidFolder(Output))
   {
    if(!EditorUtility.DisplayDialog("Reconstruir?","Generated sera apagada. Preserve alteracoes em outra pasta.","Reconstruir","Cancelar"))return;
    AssetDatabase.DeleteAsset(Output);
   }
   Directory.CreateDirectory(Output);AssetDatabase.Refresh();
   ConfigureURP();
   RigDefinition definition=JsonUtility.FromJson<RigDefinition>(File.ReadAllText(Data+"Rig.json"));
   Mesh mesh=LoadMesh();AssetDatabase.CreateAsset(mesh,Output+"/CharacterMesh.asset");
   EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
   GameObject player=new GameObject("Player");player.layer=2;player.transform.position=Vector3.up*.05f;
   CharacterController cc=player.AddComponent<CharacterController>();cc.height=1.9f;cc.radius=.28f;cc.center=Vector3.up*.95f;cc.skinWidth=.03f;cc.stepOffset=.25f;
   Transform visual=new GameObject("Visual").transform;visual.SetParent(player.transform,false);visual.localPosition=Vector3.up*.951641f;
   Transform[] bones=new Transform[definition.bones.Length];
   for(int i=0;i<bones.Length;i++)
   {
    BoneDefinition b=definition.bones[i];bones[i]=new GameObject(b.name).transform;
    bones[i].SetParent(b.parent<0?visual:bones[b.parent],false);
    bones[i].localPosition=b.position-(b.parent<0?Vector3.zero:definition.bones[b.parent].position);
   }
   SkinnedMeshRenderer renderer=visual.gameObject.AddComponent<SkinnedMeshRenderer>();
   Matrix4x4[] bind=new Matrix4x4[bones.Length];for(int i=0;i<bones.Length;i++)bind[i]=bones[i].worldToLocalMatrix*visual.localToWorldMatrix;
   mesh.bindposes=bind;renderer.sharedMesh=mesh;renderer.bones=bones;renderer.rootBone=bones[0];renderer.quality=SkinQuality.Bone4;
   renderer.localBounds=new Bounds(Vector3.zero,new Vector3(3,3,3));renderer.updateWhenOffscreen=false;
   Material material=new Material(Shader.Find("AetheriaCharacter/Toon"));material.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>(Data+"BaseColor.jpg"));
   AssetDatabase.CreateAsset(material,Output+"/Character.mat");renderer.sharedMaterial=material;
   Animator animator=visual.gameObject.AddComponent<Animator>();animator.applyRootMotion=false;
   AnimatorController controller=AnimatorController.CreateAnimatorControllerAtPath(Output+"/Character.controller");
   controller.AddParameter("Speed",AnimatorControllerParameterType.Float);controller.AddParameter("Jump",AnimatorControllerParameterType.Trigger);controller.AddParameter("Attack",AnimatorControllerParameterType.Trigger);
   AnimationClip[] clips=new AnimationClip[definition.clips.Length];
   for(int i=0;i<clips.Length;i++)clips[i]=MakeClip(definition.clips[i],bones,visual);
   AnimatorStateMachine sm=controller.layers[0].stateMachine;
   AnimatorState locomotion=sm.AddState("Locomotion");sm.defaultState=locomotion;
   BlendTree tree=new BlendTree{name="LocomotionSpeed",blendType=BlendTreeType.Simple1D,blendParameter="Speed",useAutomaticThresholds=false};
   AssetDatabase.AddObjectToAsset(tree,controller);tree.AddChild(clips[0],0);tree.AddChild(clips[1],1.8f);tree.AddChild(clips[2],4.5f);tree.AddChild(clips[3],7);locomotion.motion=tree;
   for(int i=4;i<6;i++)
   {
    AnimatorState state=sm.AddState(definition.clips[i].name);state.motion=clips[i];
    AnimatorStateTransition enter=sm.AddAnyStateTransition(state);enter.hasExitTime=false;enter.duration=.07f;enter.canTransitionToSelf=false;
    enter.AddCondition(AnimatorConditionMode.If,0,definition.clips[i].name);
    AnimatorStateTransition exit=state.AddTransition(locomotion);exit.hasExitTime=true;exit.exitTime=.9f;exit.duration=.1f;
   }
   animator.runtimeAnimatorController=controller;
   GameObject cameraObject=new GameObject("Main Camera");cameraObject.tag="MainCamera";
   Camera camera=cameraObject.AddComponent<Camera>();cameraObject.AddComponent<AudioListener>();camera.nearClipPlane=.08f;camera.farClipPlane=120;camera.fieldOfView=60;
   camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.55f,.75f,.9f);
   cameraObject.transform.position=new Vector3(0,2,-4);
   UniversalAdditionalCameraData cameraData=camera.GetUniversalAdditionalCameraData();cameraData.antialiasing=AntialiasingMode.SubpixelMorphologicalAntiAliasing;
   CharacterDemo demo=player.AddComponent<CharacterDemo>();demo.visual=visual;demo.animator=animator;demo.viewCamera=camera;
   GameObject floor=GameObject.CreatePrimitive(PrimitiveType.Cube);floor.name="WalkableFloor";floor.transform.position=new Vector3(0,-.2f,0);floor.transform.localScale=new Vector3(60,.4f,60);
   Material floorMaterial=new Material(Shader.Find("AetheriaCharacter/Toon"));floorMaterial.SetColor("_BaseColor",new Color(.4f,.58f,.3f));AssetDatabase.CreateAsset(floorMaterial,Output+"/Ground.mat");floor.GetComponent<Renderer>().sharedMaterial=floorMaterial;
   for(int i=0;i<6;i++){GameObject obstacle=GameObject.CreatePrimitive(PrimitiveType.Cube);obstacle.name="CollisionTest";obstacle.transform.position=new Vector3(-7+i*2.8f,.5f,8);obstacle.transform.localScale=new Vector3(1,1+i*.2f,1);obstacle.GetComponent<Renderer>().sharedMaterial=floorMaterial;}
   GameObject sun=new GameObject("Sun");Light light=sun.AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.1f;light.shadows=LightShadows.Soft;sun.transform.rotation=Quaternion.Euler(45,-30,0);RenderSettings.sun=light;
   RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.6f,.7f,.85f);RenderSettings.ambientEquatorColor=new Color(.4f,.45f,.5f);RenderSettings.ambientGroundColor=new Color(.2f,.2f,.3f);
   PrefabUtility.SaveAsPrefabAsset(player,Output+"/Player.prefab");
   EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(),Output+"/CharacterTest.unity");
   AssetDatabase.SaveAssets();Selection.activeGameObject=player;
   Debug.Log("Personagem preparado. Play para testar. Rig AUTOMATICO EXPERIMENTAL; revisar deformacoes.");
  }
  static Mesh LoadMesh()
  {
   using(BinaryReader r=new BinaryReader(File.OpenRead(Data+"CharacterMesh.bytes")))
   {
    int count=r.ReadInt32(),indexCount=r.ReadInt32();Vector3[] positions=new Vector3[count],normals=new Vector3[count];Vector2[] uv=new Vector2[count];int[] indices=new int[indexCount];
    for(int i=0;i<count;i++)positions[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
    for(int i=0;i<count;i++)normals[i]=new Vector3(r.ReadSingle(),r.ReadSingle(),r.ReadSingle());
    for(int i=0;i<count;i++)uv[i]=new Vector2(r.ReadSingle(),r.ReadSingle());
    for(int i=0;i<indexCount;i++)indices[i]=r.ReadInt32();
    BoneWeight[] weights=new BoneWeight[count];
    for(int i=0;i<count;i++){weights[i].boneIndex0=r.ReadUInt16();weights[i].boneIndex1=r.ReadUInt16();weights[i].boneIndex2=r.ReadUInt16();weights[i].boneIndex3=r.ReadUInt16();}
    for(int i=0;i<count;i++){weights[i].weight0=r.ReadSingle();weights[i].weight1=r.ReadSingle();weights[i].weight2=r.ReadSingle();weights[i].weight3=r.ReadSingle();}
    Mesh mesh=new Mesh{name="Aetheria_AutoRig_Mesh",indexFormat=IndexFormat.UInt32};mesh.vertices=positions;mesh.normals=normals;mesh.uv=uv;mesh.triangles=indices;mesh.boneWeights=weights;mesh.RecalculateBounds();return mesh;
   }
  }
  static AnimationClip MakeClip(ClipDefinition data,Transform[] bones,Transform root)
  {
   AnimationClip clip=new AnimationClip{name=data.name,frameRate=30};
   foreach(TrackDefinition track in data.tracks)
   {
    string path=AnimationUtility.CalculateTransformPath(bones[track.bone],root);
    for(int component=0;component<4;component++)
    {
     AnimationCurve curve=new AnimationCurve();
     for(int k=0;k<data.times.Length;k++)curve.AddKey(data.times[k],track.rotations[k][component]);
     for(int k=0;k<curve.length;k++){AnimationUtility.SetKeyLeftTangentMode(curve,k,AnimationUtility.TangentMode.Linear);AnimationUtility.SetKeyRightTangentMode(curve,k,AnimationUtility.TangentMode.Linear);}
     AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,typeof(Transform),"m_LocalRotation."+"xyzw"[component]),curve);
    }
   }
   clip.EnsureQuaternionContinuity();AnimationClipSettings settings=AnimationUtility.GetAnimationClipSettings(clip);settings.loopTime=data.name!="Jump"&&data.name!="Attack";AnimationUtility.SetAnimationClipSettings(clip,settings);
   AssetDatabase.CreateAsset(clip,Output+"/"+data.name+".anim");return clip;
  }
  static void ConfigureURP()
  {
   UniversalRendererData renderer=ScriptableObject.CreateInstance<UniversalRendererData>();AssetDatabase.CreateAsset(renderer,Output+"/Renderer.asset");
   UniversalRenderPipelineAsset pipeline=ScriptableObject.CreateInstance<UniversalRenderPipelineAsset>();SerializedObject so=new SerializedObject(pipeline);
   SerializedProperty list=so.FindProperty("m_RendererDataList");if(list==null)throw new System.InvalidOperationException("URP incompativel. Use 17.0.3.");list.arraySize=1;list.GetArrayElementAtIndex(0).objectReferenceValue=renderer;
   Set(so,"m_MainLightShadowsSupported",true);Set(so,"m_SoftShadowsSupported",true);so.ApplyModifiedPropertiesWithoutUndo();
   AssetDatabase.CreateAsset(pipeline,Output+"/URP.asset");GraphicsSettings.defaultRenderPipeline=pipeline;QualitySettings.renderPipeline=pipeline;PlayerSettings.colorSpace=ColorSpace.Linear;
  }
  static void Set(SerializedObject so,string key,bool value){SerializedProperty p=so.FindProperty(key);if(p!=null)p.boolValue=value;}
 }
}
