Shader "AetheriaCharacter/Toon"
{
 Properties { _BaseMap("Texture",2D)="white"{} _BaseColor("Color",Color)=(1,1,1,1) _ShadowTint("Shadow",Color)=(.50,.53,.7,1) }
 SubShader
 {
 Tags {"RenderPipeline"="UniversalPipeline" "RenderType"="Opaque"}
 HLSLINCLUDE
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
 TEXTURE2D(_BaseMap); SAMPLER(sampler_BaseMap);
 CBUFFER_START(UnityPerMaterial)
 float4 _BaseMap_ST, _BaseColor, _ShadowTint;
 CBUFFER_END
 ENDHLSL
 Pass
 {
 Tags {"LightMode"="UniversalForwardOnly"}
 Cull Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
 #pragma multi_compile_fragment _ _SHADOWS_SOFT
 struct A {float4 p:POSITION; float3 n:NORMAL; float2 uv:TEXCOORD0;};
 struct V {float4 p:SV_POSITION; float3 w:TEXCOORD0; float3 n:TEXCOORD1; float2 uv:TEXCOORD2;};
 V vert(A i){V o; o.w=TransformObjectToWorld(i.p.xyz);o.p=TransformWorldToHClip(o.w);o.n=TransformObjectToWorldNormal(i.n);o.uv=TRANSFORM_TEX(i.uv,_BaseMap);return o;}
 half4 frag(V i):SV_Target
 {
 #if defined(_MAIN_LIGHT_SHADOWS_SCREEN)
 float4 sc=ComputeScreenPos(TransformWorldToHClip(i.w));
 #else
 float4 sc=TransformWorldToShadowCoord(i.w);
 #endif
 Light l=GetMainLight(sc);float3 n=normalize(i.n);float ndl=saturate(dot(n,l.direction));float width=max(.025,fwidth(ndl));
 float band=smoothstep(.4-width,.4+width,ndl)*l.shadowAttenuation;
 float3 c=SAMPLE_TEXTURE2D(_BaseMap,sampler_BaseMap,i.uv).rgb*_BaseColor.rgb;
 return half4(c*(lerp(_ShadowTint.rgb,l.color,band)+max(SampleSH(n),0)*.2),1);
 }
 ENDHLSL
 }
 Pass
 {
 Name "ShadowCaster" Tags {"LightMode"="ShadowCaster"}
 ZWrite On ColorMask 0 Cull Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 float3 _LightDirection;
 struct A{float4 p:POSITION;float3 n:NORMAL;};
 float4 vert(A i):SV_POSITION
 {
 float3 w=TransformObjectToWorld(i.p.xyz);float4 c=TransformWorldToHClip(ApplyShadowBias(w,TransformObjectToWorldNormal(i.n),_LightDirection));
 #if UNITY_REVERSED_Z
 c.z=min(c.z,UNITY_NEAR_CLIP_VALUE);
 #else
 c.z=max(c.z,UNITY_NEAR_CLIP_VALUE);
 #endif
 return c;
 }
 half4 frag():SV_Target{return 0;}
 ENDHLSL
 }
 }
}
