using UnityEngine;
namespace AetheriaCharacter
{
 [System.Serializable] public class BoneDefinition { public string name; public int parent; public Vector3 position; }
 [System.Serializable] public class TrackDefinition { public int bone; public Quaternion[] rotations; }
 [System.Serializable] public class ClipDefinition { public string name; public float duration; public float[] times; public TrackDefinition[] tracks; }
 [System.Serializable] public class RigDefinition { public BoneDefinition[] bones; public ClipDefinition[] clips; }
}
