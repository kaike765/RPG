using UnityEngine;
using UnityEngine.InputSystem;
namespace AetheriaCharacter
{
 [RequireComponent(typeof(CharacterController))]
 public sealed class CharacterDemo : MonoBehaviour
 {
  public Transform visual;
  public Animator animator;
  public Camera viewCamera;
  public LayerMask groundMask=1;
  public float walkSpeed=1.8f,runSpeed=4.5f,sprintSpeed=7f;
  CharacterController cc;
  Vector3 velocity;
  float vertical,yaw,pitch=18,animationSpeed,coyote,buffer;
  bool grounded, consumed;
  static readonly int Speed=Animator.StringToHash("Speed"),Jump=Animator.StringToHash("Jump"),Attack=Animator.StringToHash("Attack");
  void Awake(){cc=GetComponent<CharacterController>(); if(animator)animator.applyRootMotion=false;}
  void Start(){Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;}
  bool Ground()
  {
   Vector3 p=transform.position+Vector3.up*.16f;
   if(!Physics.CheckSphere(p,.22f,groundMask,QueryTriggerInteraction.Ignore))return false;
   return Physics.SphereCast(transform.position+Vector3.up*.45f,.2f,Vector3.down,out RaycastHit hit,.38f,groundMask,QueryTriggerInteraction.Ignore)&&Vector3.Angle(hit.normal,Vector3.up)<=cc.slopeLimit;
  }
  void Update()
  {
   float dt=Time.deltaTime;if(dt<=0)return;
   Keyboard k=Keyboard.current;Mouse m=Mouse.current;
   if(k!=null&&k.escapeKey.wasPressedThisFrame){bool unlocked=Cursor.lockState==CursorLockMode.Locked;Cursor.lockState=unlocked?CursorLockMode.None:CursorLockMode.Locked;Cursor.visible=unlocked;}
   bool input=Cursor.lockState==CursorLockMode.Locked;
   Vector2 move=Vector2.zero;
   if(k!=null&&input){move.x=(k.dKey.isPressed?1:0)-(k.aKey.isPressed?1:0);move.y=(k.wKey.isPressed?1:0)-(k.sKey.isPressed?1:0);}
   move=Vector2.ClampMagnitude(move,1);
   if(m!=null&&input){Vector2 delta=m.delta.ReadValue();yaw+=delta.x*.12f;pitch=Mathf.Clamp(pitch-delta.y*.12f,-10,65);}
   Vector3 f=Quaternion.Euler(0,yaw,0)*Vector3.forward;
   Vector3 direction=f*move.y+Vector3.Cross(Vector3.up,f)*move.x;
   float speed=k!=null&&k.leftShiftKey.isPressed?sprintSpeed:k!=null&&k.leftCtrlKey.isPressed?walkSpeed:runSpeed;
   grounded=vertical<=0&&Ground();
   if(grounded){coyote=.12f;consumed=false;}else coyote=Mathf.Max(0,coyote-dt);
   buffer=Mathf.Max(0,buffer-dt);if(k!=null&&input&&k.spaceKey.wasPressedThisFrame)buffer=.12f;
   velocity=Vector3.MoveTowards(velocity,direction*speed,(grounded?20:6)*dt);
   if(direction.sqrMagnitude>.001f)visual.rotation=Quaternion.Slerp(visual.rotation,Quaternion.LookRotation(direction),1-Mathf.Exp(-14*dt));
   if(grounded&&vertical<0)vertical=-2;
   if(buffer>0&&coyote>0&&!consumed){vertical=Mathf.Sqrt(70);buffer=coyote=0;consumed=true;if(animator)animator.SetTrigger(Jump);}
   vertical=Mathf.Max(-45,vertical-25*dt);
   Vector3 before=transform.position;CollisionFlags flags=cc.Move((velocity+Vector3.up*vertical)*dt);
   if((flags&CollisionFlags.Above)!=0&&vertical>0)vertical=0;
   Vector3 displacement=transform.position-before;displacement.y=0;
   animationSpeed=Mathf.Lerp(animationSpeed,displacement.magnitude/dt,1-Mathf.Exp(-12*dt));
   if(animator){animator.SetFloat(Speed,animationSpeed);if(m!=null&&input&&m.leftButton.wasPressedThisFrame)animator.SetTrigger(Attack);}
   if(transform.position.y<-15){cc.enabled=false;transform.position=new Vector3(0,.1f,0);cc.enabled=true;vertical=0;}
  }
  void LateUpdate()
  {
   if(!viewCamera)return;
   Quaternion r=Quaternion.Euler(pitch,yaw,0);Vector3 target=transform.position+Vector3.up*1.3f,back=r*Vector3.back;
   float distance=4;if(Physics.SphereCast(target,.18f,back,out RaycastHit hit,4,groundMask,QueryTriggerInteraction.Ignore))distance=Mathf.Max(.15f,hit.distance-.08f);
   viewCamera.transform.position=Vector3.Lerp(viewCamera.transform.position,target+back*distance,1-Mathf.Exp(-20*Time.deltaTime));viewCamera.transform.rotation=r;
  }
  void OnGUI()
  {
   GUI.Box(new Rect(15,15,550,100),"AETHERIA — teste de rig automatico experimental");
   GUI.Label(new Rect(30,45,520,60),"WASD: mover | Shift: sprint | Ctrl: andar | Espaco: pular\nMouse: camera | Clique: animacao de ataque | Esc: cursor\nRig e pesos automaticos: verificar roupa, ombros e pernas em movimento.");
  }
  void OnDisable(){Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
 }
}
